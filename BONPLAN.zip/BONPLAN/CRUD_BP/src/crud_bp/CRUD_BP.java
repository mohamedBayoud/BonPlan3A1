/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crud_bp;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import static java.util.Collections.list;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class CRUD_BP {
    
static DataSource ds = new DataSource();

public static void AjouterHotel (BP  bp) {
        PreparedStatement ste;
        try {
              String req= "insert into bonplan values(?,?,?,?,?,?,?,?,?,?)";
            ste = ds.GetConnection().prepareStatement(req);
            
            ste.setInt(1,bp.getIdBonPlan());
            ste.setString(2,bp.getNom());
            ste.setString(3,bp.getPhoto());
            ste.setString(4,bp.getDescription());
            ste.setString(5,bp.getAdresse());
            ste.setString(6,bp.getVille());
            ste.setString(7,bp.getType());
            ste.setInt(8,0);
            ste.setInt(9,0);
            ste.setInt(10,0);
  
        ste.executeUpdate();
        
        } catch (SQLException ex) {
            Logger.getLogger(CRUD_BP.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
/*public static void AjouterResto (Culinaire c) {
        PreparedStatement ste;
        try {
              String req= "insert into bonplan values(?,?,?,?,?,?,?,?)";
            ste = ds.GetConnection().prepareStatement(req);
            
            ste.setInt(1,c.getIdBonPlan());
            ste.setString(2,c.getNom());
            ste.setString(3,c.getPhoto());
            ste.setString(4,c.getDescription());
            ste.setString(5,c.getAdresse());
            ste.setString(6,c.getVille());
            ste.setString(7,c.getType());
            ste.setInt(8,c.getNbrePlace());
  
        ste.executeUpdate();
        
        } catch (SQLException ex) {
            Logger.getLogger(CRUD_BP.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }*/
/////////////////////////////////////////////////////////////////////////////////////////////////
public static void SupprimerBP(BP bp) {
        Statement ste;
        try {
            ste = ds.GetConnection().createStatement();
            String req= "delete from bonplan where idBonPlan="+bp.getIdBonPlan()+"";
        ste.executeUpdate(req);
        
        } catch (SQLException ex) {
            Logger.getLogger(CRUD_BP.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
///////////////////////////////////////////////////////////////////////////////////////////////////
public static void ModifierHotel(BP bp) {
          PreparedStatement ste;
        try {
            String req= "update bonplan set nom=?,photo=?,description=?,adresse=?,ville=? , type=?  where idBonPlan=?";
            ste = ds.GetConnection().prepareStatement(req);
            
            ste.setString(1,bp.getNom());
            ste.setString(2,bp.getPhoto());
            ste.setString(3,bp.getDescription());
            ste.setString(4,bp.getAdresse());
            ste.setString(5,bp.getVille());
            ste.setString(6,bp.getType());
            //ste.setInt(7,s.getNbreChambreDispo());
            //ste.setInt(8,s.getPrixnuit());
            ste.setInt(7,bp.getIdBonPlan());

            
        ste.executeUpdate();
        
        } catch (SQLException ex) {
            Logger.getLogger(CRUD_BP.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
/////////////////////////////////////////////////////////////////////////////////////////////////////
     /*public static void ModifierResto(int id ,Culinaire c) {
          PreparedStatement ste;
        try {
            String req= "update bonplan set nom=?,photo=?,description=?,adresse=?,ville=?,nbrPlace=? where idBonPlan=?";
            ste = ds.GetConnection().prepareStatement(req);
            
            ste.setString(1,c.getNom());
            ste.setString(2,c.getPhoto());
            ste.setString(3,c.getDescription());
            ste.setString(4,c.getAdresse());
            ste.setString(5,c.getVille());
            ste.setString(6,c.getType());
            ste.setInt(7,c.getNbrePlace());
            ste.setInt(8,c.getIdBonPlan());

        ste.executeUpdate();
        
        } catch (SQLException ex) {
            Logger.getLogger(CRUD_BP.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }  */
 ////////////////////////////////////////////////////////////////////////////////////////
     public static List<BP> AfficherHotel() {
         
       PreparedStatement ste;
             List<BP> list = new ArrayList<>();
        try {
         
            String req= "SELECT *from bonplan";
            ste = ds.GetConnection().prepareStatement(req);
            
            
        ResultSet result =ste.executeQuery();
        
        
        while(result.next()){
             BP bp =new BP(result.getInt("idBonPlan"),result.getString("nom"), result.getString("photo"),
                    result.getString("description"),result.getString("adresse"),result.getString("ville")
                    ,result.getString("type"));
            
            list.add(bp);
        }
        
        } catch (SQLException ex) {
            Logger.getLogger(CRUD_BP.class.getName()).log(Level.SEVERE, null, ex);
        }
       return list;
        
        
    }
     
     /*public static List<Sejourner> AfficherResto() {
          PreparedStatement ste;
             List<Sejourner> list = new ArrayList<>();
        try {
         
            String req= "SELECT *from bonplan";
            ste = ds.GetConnection().prepareStatement(req);
            
            
        ResultSet result =ste.executeQuery();
        
        
        while(result.next()){
            BP c1 =new Culinaire(result.getInt("idBonPlan"),result.getString("nom"), result.getString("photo"),
     result.getString("description"),result.getString("adresse"),result.getString("ville"),result.getString("type"),result.getNbrePlace("nbrePlace"));
            
            list.add((Culinaire) c1);
        }
        
        } catch (SQLException ex) {
            Logger.getLogger(CRUD_BP.class.getName()).log(Level.SEVERE, null, ex);
        }
       return list;
        
    }*/

    public static void main(String[] args) {
        
        BP bp = new BP (1,"Villa Di Don","img","c'est un hotel...","Carthage Hannibal","Tunis","Hotel");
        BP bp2 =new BP (2,"noussa","img","c'est un ...","La Marsa","Tunis","Resto");
        
        //AjouterHotel(bp);
        SupprimerBP(bp);
        ModifierHotel(bp2);
        AfficherHotel().forEach(System.out::println);
        
        
        
        

    }
}
    

