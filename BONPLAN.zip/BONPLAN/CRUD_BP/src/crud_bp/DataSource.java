/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crud_bp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DataSource {
    
    final String ur1 ="jdbc:mysql://localhost:8889/bonplan";
    final String user ="root";
    final String Password="root";
    Connection connection;
    
    public DataSource (){
        
        try {
            connection = DriverManager.getConnection(ur1, user,Password) ;
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
   
    public Connection GetConnection (){
        return connection;
    }
    
}
