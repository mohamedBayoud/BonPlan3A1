/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crud_bp;

import java.util.Objects;

/**
 *
 * @author senda
 */
public class BP {
    
    protected int idBonPlan ; 
    protected String nom ; 
    protected String photo ; 
    protected String description ; 
    protected String adresse ; 
    protected String ville ; 
    protected String type ; 

    public BP(){}
    public BP(int idBonPlan, String nom, String photo, String description, String adresse, String ville, String type) {
        this.idBonPlan = idBonPlan;
        this.nom = nom;
        this.photo = photo;
        this.description = description;
        this.adresse = adresse;
        this.ville = ville;
        this.type = type;
    }

    public int getIdBonPlan() {
        return idBonPlan;
    }

    public void setIdBonPlan(int idBonPlan) {
        this.idBonPlan = idBonPlan;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

   

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final BP other = (BP) obj;
        if (this.idBonPlan != other.idBonPlan) {
            return false;
        }
        if (!Objects.equals(this.nom, other.nom)) {
            return false;
        }
        if (!Objects.equals(this.photo, other.photo)) {
            return false;
        }
        if (!Objects.equals(this.description, other.description)) {
            return false;
        }
        if (!Objects.equals(this.adresse, other.adresse)) {
            return false;
        }
        if (!Objects.equals(this.ville, other.ville)) {
            return false;
        }
        if (!Objects.equals(this.type, other.type)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "BP{" + "idBonPlan=" + idBonPlan + ", nom=" + nom + ", photo=" + photo + ", description=" + description + ", adresse=" + adresse + ", ville=" + ville + ", type=" + type + '}';
    }
    
    
    
    
    
}
