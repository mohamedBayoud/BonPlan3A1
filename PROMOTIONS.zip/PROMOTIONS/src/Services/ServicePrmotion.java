/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import ConnexionBd.DataSource;
import Entites.Promotion;
import java.sql.Date;
import java.sql.ResultSet;
import java.util.Scanner;

/**
 *
 * @author Omar
 */
public class ServicePrmotion {
       public Connection con = DataSource.getInstance().getConnection();
    public Statement ste;

    public ServicePrmotion() 
    {
        try {
            ste=con.createStatement();
            }catch (SQLException ex) {
            Logger.getLogger(ServicePrmotion.class.getName()).log(Level.SEVERE, null, ex);
                                     }
    
    }
    
     public void AjouterPromotion(Promotion P) throws SQLException
    
     {
         System.out.println("Veuillez Entrer les Donnees");
         String req ="INSERT INTO promotion (titre,description,image,prix,type,dateFin) VALUES (?,?,?,?,?,?)";
         PreparedStatement pre = con.prepareStatement(req);
         pre.setString(1,P.getTitre());
         pre.setString(2, P.getDescripton());
         pre.setString(3, P.getImage());
         pre.setInt(3, P.getPrix());
         pre.setString(3, P.getType());
         pre.setDate(3, P.getDateFin());

         pre.executeUpdate();
         System.out.println("Promotion Ajoutée");
     
     }
          public void AjouterPromotion2() throws SQLException
          {
              
                       System.out.println("Veuillez Entrer les Donnees");

              Scanner sc = new Scanner(System.in);
              
              String titre = sc.nextLine(); 
              String description = sc.nextLine();
              String image = sc.nextLine();

              int prix = sc.nextInt();
              String type = sc.nextLine();
              sc.nextLine();
              int jj = sc.nextInt();
               int mm = sc.nextInt();

               int aa = sc.nextInt();

              Date dateFin = new Date(jj,mm,aa);

              
              String req="INSERT INTO promotion(titre,description,image,prix,type,dateFin) VALUES ('"+titre+"','"+description+"','"+image+"','"+prix+"','"+type+"','"+dateFin+"')";
           Statement ste = con.prepareStatement(req);
           ste.executeUpdate(req);
           
                    System.out.println("Promotion Ajoutée");
          }
          
          public void supprimerPromotion() throws SQLException
    {
        Scanner sc = new Scanner(System.in);
              
              String titre = sc.nextLine(); 
        String req = "DELETE FROM promotion where (titre = '"+titre+"') ";
        ste.executeUpdate(req);
                            System.out.println("prommotion Supprimeé avec Succees");
    }
          
            public void ModifierPromotion() throws SQLException
    {
        Scanner sc = new Scanner(System.in);
              
              /*
              String titre = sc.nextLine(); 
              String description = sc.nextLine(); 
              String image = sc.nextLine(); 
              int prix = sc.nextInt();
              String type = sc.nextLine();
              String dateFin = sc.nextLine(); 
*/
              System.out.println("Donner l id  modifier ");
              
              int id = sc.nextInt();
              System.out.println("veuillez entre les valeur ");

               String titre = sc.nextLine();
              String description = sc.nextLine();
              String image = sc.nextLine();
                                          sc.nextLine();

              int prix = sc.nextInt();

              String type = sc.nextLine();
                                                        sc.nextLine();

              int jj = sc.nextInt();
               int mm = sc.nextInt();

               int aa = 7782;
                                                                       sc.nextLine();

              Date dateFin = new Date(jj,mm,aa);


              String req = "UPDATE promotion set (titre= '"+titre+"',description='"+description+"',image='"+image+"',prix='"+prix+"',type='"+type+"',dateFin='"+dateFin+"') where (idPromotion='"+id+"') ";
     //  String req="UPDATE `promotion` SET `titre`=[value-2],`description`=[value-3],`image`=[value-4],`prix`=[value-5],`type`,`dateFin` WHERE idPromotion==='"+id+"'";
              ste.executeUpdate(req);
                            System.out.println("promotion Modifie avec Succees");
    }
            
             public void ConsulterPromotion() throws SQLException
    {
              ResultSet res;
              String req = "SELECT * from promotion";
              res=ste.executeQuery(req);
              while (res.next()) {
                  System.out.println(res.getInt("idPromotion"));
                  System.out.println(res.getString("Titre"));
                  System.out.println(res.getString("Description"));
                  System.out.println(res.getString("Image"));
                  System.out.println(res.getInt("Prix"));

                  System.out.println(res.getString("Type"));
                  System.out.println(res.getString("DateFin"));


            
        }
                           
    }
}