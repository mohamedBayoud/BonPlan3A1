package Entites;
import java.sql.Date;
import java.util.Objects;


public class Promotion {
 private int id;
 private String titre;
 private String descripton;
  private String image;
  private Date dateFin;
  private int prix;
  private String type;

    public Promotion() {
    }

    public Promotion(String titre, String descripton, String image, Date dateFin, int prix, String type) {
        this.titre = titre;
        this.descripton = descripton;
        this.image = image;
        this.dateFin = dateFin;
        this.prix = prix;
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public String getTitre() {
        return titre;
    }

    public String getDescripton() {
        return descripton;
    }

    public String getImage() {
        return image;
    }

    public Date getDateFin() {
        return dateFin;
    }

    public int getPrix() {
        return prix;
    }

    public String getType() {
        return type;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public void setDescripton(String descripton) {
        this.descripton = descripton;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setDateFin(Date dateFin) {
        this.dateFin = dateFin;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 29 * hash + this.id;
        hash = 29 * hash + Objects.hashCode(this.titre);
        hash = 29 * hash + Objects.hashCode(this.descripton);
        hash = 29 * hash + Objects.hashCode(this.image);
        hash = 29 * hash + Objects.hashCode(this.dateFin);
        hash = 29 * hash + Objects.hashCode(this.prix);
        hash = 29 * hash + Objects.hashCode(this.type);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Promotion other = (Promotion) obj;
        return true;
    }

    @Override
    public String toString() {
        return "Promotion{" + "id=" + id + ", titre=" + titre + ", descripton=" + descripton + ", image=" + image + ", dateFin=" + dateFin + ", prix=" + prix + ", type=" + type + '}';
    }



   

   
   
  
    
}
