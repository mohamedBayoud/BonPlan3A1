/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package partage;

import Entites.Promotion;
import Services.ServicePrmotion;
import java.sql.Date;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Omar
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
 Promotion P = new Promotion("promo","prootion hotel bla ba bla",".png",new Date(2020/12/2),150,"1");   
 Promotion P2 = new Promotion();
      

            int c;
                Scanner in = new Scanner(System.in);
                ServicePrmotion sv= new ServicePrmotion();
                        do{

            do{
                System.out.println("*****************************");
                System.out.println("1 - Ajouter Un Promotion");
                System.out.println("2 - Supprimer Un Promotion");
                System.out.println("3 - Consulter un Promotion");
                System.out.println("4 - Modifier un Promotion");
                System.out.println("0 - Quitter");
                System.out.println("*****************************");
                c = in.nextInt();
            }while( c < 0 || c > 5);
                 if( c == 0) return;
            else if(c == 1){
                try {
            sv.AjouterPromotion2(); 
          } catch (SQLException ex) {
            Logger.getLogger(Promotion.class.getName()).log(Level.SEVERE, null, ex);
        }
            }
                  else if(c == 2){
                 try {
            sv.supprimerPromotion();
          } catch (SQLException ex) {
            Logger.getLogger(Promotion.class.getName()).log(Level.SEVERE, null, ex);
        }
                  } else if(c == 3){
                       try {
            sv.ConsulterPromotion();
          } catch (SQLException ex) {
            Logger.getLogger(Promotion.class.getName()).log(Level.SEVERE, null, ex);
        }
                  }
                 else
                  {
                       try {
            sv.ModifierPromotion();
          } catch (SQLException ex) {
            Logger.getLogger(Promotion.class.getName()).log(Level.SEVERE, null, ex);
        }
                  }
                  }while( c != 0);
    }
}

           


